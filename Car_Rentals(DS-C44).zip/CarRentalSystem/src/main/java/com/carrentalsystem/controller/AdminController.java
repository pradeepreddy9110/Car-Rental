package com.carrentalsystem.controller;

import com.carrentalsystem.entity.Car;
import com.carrentalsystem.service.CarService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final CarService carService;

    public AdminController(CarService carService) {
        this.carService = carService;
    }

    @GetMapping("/cars")
    public String manageCars(Model model) {
        model.addAttribute("cars", carService.findAvailableCars());
        return "admin/cars";
    }

    @GetMapping("/cars/add")
    public String showCarForm(Model model) {
        model.addAttribute("car", new Car());
        return "admin/car-form";
    }

    @PostMapping("/cars/add")
    public String addCar(@ModelAttribute Car car) {
        car.setAvailable(true);
        carService.saveCar(car);
        return "redirect:/admin/cars";
    }
}