package com.carrentalsystem.controller;

import com.carrentalsystem.dto.BookingDTO;
import com.carrentalsystem.entity.Booking;
import com.carrentalsystem.entity.Car;
import com.carrentalsystem.service.BookingService;
import com.carrentalsystem.service.CarService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@SuppressWarnings("unused")
@Controller
public class BookingController {

    private final BookingService bookingService;
    private final CarService carService;

    public BookingController(BookingService bookingService, CarService carService) {
        this.bookingService = bookingService;
        this.carService = carService;
    }

    @GetMapping("/book/{carId}")
    public String showBookingForm(@PathVariable Long carId, Model model) {
        Car car = carService.findById(carId);

        if (car == null) {
            return "redirect:/cars?error=Car not found"; // Redirect if car is missing
        }

        model.addAttribute("car", car); // ✅ Ensure the car object is added to the model
        model.addAttribute("bookingDTO", new BookingDTO());

        return "booking-form"; // Ensure this matches your Thymeleaf file name
    }


    @PostMapping("/book")
    public String processBooking(@ModelAttribute BookingDTO bookingDTO, Model model, Authentication authentication) {
        // Get the car details again
        Car car = carService.findById(bookingDTO.getCarId());

        if (car == null) {
            model.addAttribute("error", "Car not found");
            return "booking-form";
        }

        try {
            // Get username from authentication if using Spring Security
            String username = null;
            if (authentication != null) {
                username = authentication.getName();
            }

            // Save the booking
            bookingService.createBooking(bookingDTO, username);

            // Redirect to booking confirmation or list of user bookings
            return "redirect:/my-bookings";
        } catch (Exception e) {
            model.addAttribute("error", "Failed to book the car: " + e.getMessage());
            model.addAttribute("car", car);
            return "booking-form";
        }
    }
    
    @GetMapping("/my-bookings")
    public String showMyBookings(Model model, Authentication authentication) {
        if (authentication != null) {
            String username = authentication.getName();
            List<Booking> bookings = bookingService.findBookingsByUsername(username);
            model.addAttribute("bookings", bookings);
        }
        return "my-bookings";
    }

    public BookingService getBookingService() {
        return bookingService;
    }
}