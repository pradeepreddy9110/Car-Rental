package com.carrentalsystem.controller;

import com.carrentalsystem.service.OTPService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/otp")
public class OTPController {

    private final OTPService otpService;

    public OTPController(OTPService otpService) {
        this.otpService = otpService;
    }

    @PostMapping("/send")
    public String sendOTP(@RequestParam String phoneNumber) {
        otpService.sendOTP(phoneNumber);
        return "OTP sent successfully!";
    }

    @PostMapping("/verify")
    public String verifyOTP(@RequestParam String phoneNumber, @RequestParam String otp) {
        if (otpService.verifyOTP(phoneNumber, otp)) {
            return "OTP Verified Successfully!";
        } else {
            return "Invalid or Expired OTP!";
        }
    }
}
