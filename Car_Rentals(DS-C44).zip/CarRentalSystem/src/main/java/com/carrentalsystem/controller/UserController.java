package com.carrentalsystem.controller;

import com.carrentalsystem.dto.UserDTO;
import com.carrentalsystem.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class UserController {

    private final UserService userService;

    // Constructor-based dependency injection (best practice)
    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Display the registration form
    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new UserDTO()); // Ensure UserDTO has a no-argument constructor
        return "register"; // This should match your Thymeleaf or HTML file name
    }

    // Handle user registration
    @PostMapping("/register")
    public String registerUser(@ModelAttribute("user") UserDTO userDTO, RedirectAttributes redirectAttributes) {
        try {
            userService.registerUser(userDTO);
            return "redirect:/login?success";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/register";
        }
    }
}
