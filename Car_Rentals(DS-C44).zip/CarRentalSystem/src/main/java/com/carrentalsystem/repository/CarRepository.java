package com.carrentalsystem.repository;

import com.carrentalsystem.entity.Car;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CarRepository extends JpaRepository<Car, Long> {
    List<Car> findByAvailableTrue(); // Fetch available cars only
    boolean existsByIdAndAvailableTrue(Long id); // Check if a car is available
}
