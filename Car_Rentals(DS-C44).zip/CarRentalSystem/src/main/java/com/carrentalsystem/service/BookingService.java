package com.carrentalsystem.service;

import com.carrentalsystem.dto.BookingDTO;
import com.carrentalsystem.entity.Booking;
import com.carrentalsystem.entity.Car;
import com.carrentalsystem.entity.User;
import com.carrentalsystem.repository.BookingRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;
    private final CarService carService;
    private final UserService userService;

    public BookingService(BookingRepository bookingRepository, CarService carService, UserService userService) {
        this.bookingRepository = bookingRepository;
        this.carService = carService;
        this.userService = userService;
    }

    @Transactional
    public Booking createBooking(BookingDTO bookingDTO, String userEmail) {
        User user = userService.findByEmail(userEmail);
        Car car = carService.findById(bookingDTO.getCarId());

        boolean isBooked = bookingRepository.existsByCarAndStartDateLessThanEqualAndEndDateGreaterThanEqual(
        	    car, bookingDTO.getStartDate(), bookingDTO.getEndDate()
        	);


        if (isBooked) {
            throw new RuntimeException("Car is already booked for the selected dates.");
        }

        long days = ChronoUnit.DAYS.between(bookingDTO.getStartDate(), bookingDTO.getEndDate()) + 1;
        double totalPrice = car.getRentalPrice() * days;

        Booking booking = new Booking();
        booking.setUser(user);
        booking.setCar(car);
        booking.setStartDate(bookingDTO.getStartDate());
        booking.setEndDate(bookingDTO.getEndDate());
        booking.setTotalPrice(totalPrice);
        booking.setStatus("ACTIVE"); // Using String instead of Enum
        booking.setBookingDate(LocalDate.now());

        carService.updateCarAvailability(car.getId(), false);

        return bookingRepository.save(booking);
    }

    public List<Booking> getUserBookings(String userEmail) {
        User user = userService.findByEmail(userEmail);
        return bookingRepository.findByUserOrderByBookingDateDesc(user);
    }

    public List<Booking> findBookingsByUsername(String username) {
        return getUserBookings(username);
    }
}
