package com.carrentalsystem.service;

import com.carrentalsystem.entity.Car;
import com.carrentalsystem.repository.CarRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CarService {

    private final CarRepository carRepository;

    public CarService(CarRepository carRepository) {
        this.carRepository = carRepository;
    }

    public List<Car> findAllCars() {
        return carRepository.findAll();
    }

    public List<Car> findAvailableCars() {
        return carRepository.findByAvailableTrue();
    }

    public Car findById(Long id) {
        return carRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Car not found with ID: " + id));
    }

    public Car saveCar(Car car) {
        return carRepository.save(car);
    }

    @Transactional
    public void updateCarAvailability(Long id, boolean isAvailable) {
        Car car = findById(id);  // Avoids redundant database lookup
        car.setAvailable(isAvailable);
        carRepository.save(car);
    }
}
