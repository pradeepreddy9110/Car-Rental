package com.carrentalsystem.service;

import com.carrentalsystem.config.TwilioConfig;
import com.twilio.rest.api.v2010.account.Message;
import org.springframework.stereotype.Service;
import java.util.Random;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
public class OTPService {

    private final TwilioConfig twilioConfig;
    private final Random random = new Random();
    private final Map<String, OTPEntry> otpStorage = new HashMap<>();

    public OTPService(TwilioConfig twilioConfig) {
        this.twilioConfig = twilioConfig;
    }

    public String generateOTP() {
        return String.valueOf(100000 + random.nextInt(900000)); // 6-digit OTP
    }

    public void sendOTP(String phoneNumber) {
        String otp = generateOTP();
        otpStorage.put(phoneNumber, new OTPEntry(otp, LocalDateTime.now().plusMinutes(5)));

        try {
            @SuppressWarnings("unused")
			Message message = Message.creator(
                new com.twilio.type.PhoneNumber(phoneNumber),
                new com.twilio.type.PhoneNumber(twilioConfig.getTwilioPhoneNumber()),
                "Your OTP is: " + otp
            ).create();

            System.out.println("✅ OTP Sent Successfully to " + phoneNumber + ": " + otp);
        } catch (Exception e) {
            System.out.println("❌ ERROR: OTP Sending Failed - " + e.getMessage());
        }
    }

    public boolean verifyOTP(String phoneNumber, String otp) {
        if (otpStorage.containsKey(phoneNumber)) {
            OTPEntry storedOTP = otpStorage.get(phoneNumber);
            if (storedOTP.getOtp().equals(otp) && storedOTP.getExpiryTime().isAfter(LocalDateTime.now())) {
                otpStorage.remove(phoneNumber);
                return true;
            }
        }
        return false;
    }

    private static class OTPEntry {
        private final String otp;
        private final LocalDateTime expiryTime;

        public OTPEntry(String otp, LocalDateTime expiryTime) {
            this.otp = otp;
            this.expiryTime = expiryTime;
        }

        public String getOtp() {
            return otp;
        }

        public LocalDateTime getExpiryTime() {
            return expiryTime;
        }
    }
}
